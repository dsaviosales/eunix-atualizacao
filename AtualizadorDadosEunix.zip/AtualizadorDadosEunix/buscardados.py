from utils.tratardados import tratar_numeros
import pandas as pd
from tinydb import TinyDB, Query
import requests
from tqdm import tqdm
from ratelimit import limits, sleep_and_retry
import atualizadados
import logging

logging.basicConfig(
    filename='log/download_info.log',            # Nome do arquivo de log
    level=logging.ERROR,                         # Nível mínimo (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    format='%(asctime)s - %(levelname)s - %(message)s',
    encoding='utf-8')


DB = TinyDB('eunix.json')
DADOS = Query()

CALLS = 3
PERIOD = 60

datafile = "files/fornecedores.csv"

AVISO = """

***Aviso***

Antes de começar, checar se o arquivo está salvo
com o nome "fornecedores.csv" no diretório files.

Devendo conter no minimo a coluna CGC (com letras maiúsculas).

"""

print(AVISO)

input("Digite enter para inciar...\n")

on_off = input("Deseja Trabalhar Offline? S - Sim | N - Não: ")


@sleep_and_retry
@limits(calls=CALLS, period=PERIOD)
def consulta_cnpj(cnpj):
    try:
        res = requests.get(f"https://receitaws.com.br/v1/cnpj/{cnpj}", timeout=10)
        
        if res.status_code != 200:
            logging.error(f"Erro HTTP {res.status_code} para CNPJ {cnpj}")
            return None
        
        if not res.text.strip():  # resposta vazia
            logging.error(f"Resposta vazia para CNPJ {cnpj}")
            return None
        

        dados = res.json()
        return dados

    except ValueError as e:
        logging.error(f"Erro ao converter JSON para CNPJ {cnpj}: {e}")
        return None

    except Exception as e:
        logging.error(f"Erro geral para CNPJ {cnpj}: {e}")
        return None


def download_info():
    df = pd.read_csv(datafile, encoding="utf8",dtype=str)
    df["CGC"] = df["CGC"].apply(tratar_numeros)
    df = df.drop_duplicates(subset=["CGC"])
    
    for _, f in tqdm(df.iterrows(), desc="Baixando Dados Fornecedores...", unit=" cnpj(s)"):
        
        cgcfornec = tratar_numeros(f["CGC"])
        
        if len(cgcfornec) >= 14 and not DB.contains(DADOS.cgc == cgcfornec):
            try:
                data = consulta_cnpj(cgcfornec)
                if data:
                    DB.insert({ "cgc":tratar_numeros(data["cnpj"]), 
                                "ie":"", 
                                "tipo":"F", 
                                "razaosocial":data["nome"],
                                "fantasia":data["fantasia"], 
                                "ender":data["logradouro"],
                                "numero":data["numero"], 
                                "bairro":data["bairro"],
                                "cidade":data["municipio"], 
                                "estado":data["uf"], 
                                "cep":data["cep"],
                                "tel":data["telefone"], 
                                "cnae":data["atividade_principal"],
                                "email":data["email"]})
            except Exception as e:
                logging.error(f"Erro de conexão para {cgcfornec}: {e}")


if __name__=="__main__":
    print("Iniciando Download dos Dados...")
    app = download_info()
    if on_off.upper() == "N":
        print("Atualizando Dados no Oracle...")
        updater = atualizadados.run()
    else:
        ...
    print("Atualizacao Concluída!")






