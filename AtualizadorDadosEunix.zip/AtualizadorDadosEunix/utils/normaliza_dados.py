from tinydb import TinyDB, Query
from tratardados import tratar_numeros

db = TinyDB("eunix.json")
dados = db.all()
DADOS = Query()

for item in dados:
    cgc_antigo = item.get("cgc", "")
    cgc_tratado = tratar_numeros(cgc_antigo)

    # Só atualiza se for diferente
    if cgc_tratado != cgc_antigo:
        db.update({"cgc": cgc_tratado}, DADOS.cgc == cgc_antigo)
    