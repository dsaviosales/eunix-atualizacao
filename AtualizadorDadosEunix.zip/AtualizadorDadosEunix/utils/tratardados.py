"""
Função de tratamento dos dados das consultas.

"""


def tratar_numeros(cgc):
    excluir_ponto = cgc.replace(".", "")
    excluir_traco = excluir_ponto.replace("-", "")
    excluir_barra = excluir_traco.replace("/", "")
    cgc_tratado = excluir_barra

    return cgc_tratado