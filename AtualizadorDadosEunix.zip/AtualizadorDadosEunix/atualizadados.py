from tinydb import TinyDB, Query
from utils.tratardados import tratar_numeros
from database import connectOracle
from tqdm import tqdm

DB = TinyDB("eunix.json")
cursor = DB.all()

def run():
    def updateFornec(cgc, endereco, cidade, tipo, fantasia, numeroender, bairro, cep, estado, email):
        runexec = connectOracle().cursor()
        sql = f"""UPDATE PCFORNEC SET   ENDER = '{endereco}',
                                        CIDADE = '{cidade}', 
                                        TIPOFORNEC = '{tipo}', 
                                        FANTASIA = '{fantasia}', 
                                        NUMEROEND = '{numeroender}', 
                                        BAIRRO = '{bairro}', 
                                        CEP = '{cep}', 
                                        ESTADO = '{estado}', 
                                        EMAIL = '{email}'
                    WHERE REPLACE(REPLACE(REPLACE(CGC, '.', ''), '-', ''), '/', '') = '{cgc}'
                """
        
        runexec.execute(sql)

    print("Atualizando Dados...")

    for f in tqdm(cursor, desc="Fornecedores", unit=" cadastros"):
        
        cnae = f["cnae"][0]["code"] if f["cnae"] else ""
        tipofornec = ""

        classe = int(cnae[:2])

        if classe >= 0 and classe <= 44:
            tipofornec = "I" 
        
        elif classe in [45,46]:
            tipofornec = "C"

        elif classe == 47:
            tipofornec = "V" 
        
        elif classe >= 48:
            tipofornec = "O"

        updateFornec(tratar_numeros(f["cgc"]), 
                                    f["ender"][:40],
                                    f["cidade"][0:15], 
                                    tipofornec,
                                    f["fantasia"], 
                                    f["numero"], 
                                    f["bairro"][:20], 
                                    tratar_numeros(f["cep"]), 
                                    f["estado"],
                                    f["email"])

    connectOracle().commit()
    connectOracle().close()

if __name__=="__main__":
    app = run()