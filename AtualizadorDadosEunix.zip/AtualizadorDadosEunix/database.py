import cx_Oracle as ora
from dotenv import load_dotenv
import os

load_dotenv(".\config\.env")

ORA_USER    =  os.getenv('ORA_USER')
ORA_PASS    =  os.getenv('ORA_PASS')
ORA_SID     =  os.getenv('ORA_SID')
ORA_HOST    =  os.getenv('ORA_HOST')
ORA_PORT    =  os.getenv('ORA_PORT')


def connectOracle():
    try:
        ora_conn = ora.connect(user=ORA_USER,
                               password=ORA_PASS,
                               dsn=f"{ORA_HOST}/{ORA_SID}")
        return ora_conn
    except ora.DatabaseError as e:
        print(e)
        raise

